﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace Component2;

internal class Program
{
    private static Stopwatch sw = new Stopwatch(); // Initialize Stopwatch
    private static DoublyLinkedList myLinkedList = new DoublyLinkedList();  // Declare LinkedList

    static void Main(string[] args)
    {
        MainMenu();
        Console.WriteLine("");
        Console.WriteLine("Press any key to continue...");
        Console.ReadKey();
    }

    static void MainMenu() // Main menu for loading, inserting, finding, and deleting operations
    {
        int choice;
        bool exit = false;

        while (!exit)
        {
            Console.Clear();
            Console.WriteLine("**** Custom LinkedList Menu ****");
            Console.WriteLine("1. Load File");
            Console.WriteLine("2. Insert Word");
            Console.WriteLine("3. Find Word");
            Console.WriteLine("4. Delete Word");
            Console.WriteLine("5. Print LinkedList");
            Console.WriteLine("6. Functional Test Demonstration");
            Console.WriteLine("7. Exit");
            Console.WriteLine();
            Console.Write("Enter your choice: ");

            if (int.TryParse(Console.ReadLine(), out choice))
            {
                switch (choice)
                {
                    case 1:
                        LoadMenu();
                        break;

                    case 2:
                        InsertMenu();
                        break;
                    case 3:
                        FindMenu();
                        break;
                    case 4:
                        DeleteMenu();
                        break;
                    case 5:
                        myLinkedList.Print();
                        break;
                    case 6:
                        FunctionalTest();
                        break;
                    case 7:
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please select a valid option.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a number.");
            }

            if (!exit)
            {
                Console.WriteLine("\nPress any key to return to the main menu...");
                Console.ReadKey();
            }
        }
    }

    static void LoadMenu()
    {
        Console.Clear();
        Console.WriteLine("**** Choose a File to Load *****");
        Console.WriteLine("1. 1000-words.txt");
        Console.WriteLine("2. 5000-words.txt");
        Console.WriteLine("3. 10000-words.txt");
        Console.WriteLine("4. 15000-words.txt");
        Console.WriteLine("5. 20000-words.txt");
        Console.WriteLine("6. 25000-words.txt");
        Console.WriteLine("7. 30000-words.txt");
        Console.WriteLine("8. 35000-words.txt");
        Console.WriteLine("9. 40000-words.txt");
        Console.WriteLine("10. 45000-words.txt");
        Console.WriteLine("11. 50000-words.txt");
        Console.Write("Enter your option: ");

        if (int.TryParse(Console.ReadLine(), out int opt) && opt >= 1 && opt <= 11)
        {
            // Array of file names corresponding to the menu options
            string[] fileNames = new string[]
            {
            "1000-words.txt",
            "5000-words.txt",
            "10000-words.txt",
            "15000-words.txt",
            "20000-words.txt",
            "25000-words.txt",
            "30000-words.txt",
            "35000-words.txt",
            "40000-words.txt",
            "45000-words.txt",
            "50000-words.txt"
            };

            // Get the file name based on the selected option
            string fileName = fileNames[opt - 1];
            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName);

            LoadFile(filePath); // Call the load file method
        }
        else
        {
            Console.WriteLine("Invalid option. Please try again.");
        }
    }
    static void LoadFile(string filePath)
    {
        myLinkedList.Clear(); // Clear the linked list before loading new data
        sw.Reset();
        sw.Start();

        if (File.Exists(filePath))
        {
            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (!line.StartsWith("#")) // Discard lines starting with '#'
                        {
                            myLinkedList.AddLast(line); // Add word to the linked list
                        }
                    }
                }
                Console.WriteLine($"File loaded successfully from {filePath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading file: {ex.Message}");
            }
        }
        else
        {
            Console.WriteLine($"File not found: {filePath}");
        }

        sw.Stop();
        Console.WriteLine($"Time taken to load: {sw.ElapsedMilliseconds} ms");
    }
    // Method to add a word to the linked list, checking for duplicates
    static void AddWord(string word)
    {
        sw.Reset();
        sw.Start();
        Node existingNode = myLinkedList.Find(word); // Check if the word exists

        if (existingNode == null)
        {
            myLinkedList.AddLast(word); // Add word to the end
            Console.WriteLine($"Added: {word}");
        }
        else
        {
            Console.WriteLine($"Duplicate word '{word}' discarded.");
        }
        sw.Stop();
        Console.WriteLine($"Time taken to load: {sw.ElapsedMilliseconds} ms");
    }
    //Inserting new word into the Doubly LinkedList
    static void InsertMenu()
    {
        //Inserting new word into the Doubly LinkedList
        {
            bool exit = false;

            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("**** Insert Word Menu ****");
                Console.WriteLine("1. Add First");
                Console.WriteLine("2. Add Last");
                Console.WriteLine("3. Add Before");
                Console.WriteLine("4. Add After");
                Console.WriteLine("5. Return to Main Menu");
                Console.WriteLine();
                Console.Write("Enter your choice: ");

                int choice;
                if (int.TryParse(Console.ReadLine(), out choice))
                {
                    switch (choice)
                    {
                        case 1:
                            InsertAtFirst();
                            break;

                        case 2:
                            InsertAtLast();
                            break;

                        case 3:
                            InsertBefore();
                            break;

                        case 4:
                            InsertAfter();
                            break;

                        case 5:
                            exit = true; // Return to main menu
                            break;

                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                }

                if (!exit)
                {
                    Console.WriteLine("\nPress any key to return to the insert menu...");
                    Console.ReadKey();
                }
            }
        }

        // Insert word at the beginning of the list
        static void InsertAtFirst()
        {

            Console.Clear();
            Console.WriteLine("**** Add First ****");
            Console.Write("Enter the word to insert at the beginning: ");
            string word = Console.ReadLine();            
            
            sw.Reset();
            sw.Start();
            myLinkedList.AddFirst(word);
            Console.WriteLine($"Word '{word}' added at the beginning.");
            sw.Stop();
            Console.WriteLine($"Time taken to load: {sw.Elapsed} ms");
        }

        // Insert word at the end of the list
        static void InsertAtLast()
        {

            Console.Clear();
            Console.WriteLine("**** Add Last ****");
            Console.Write("Enter the word to insert at the end: ");
            string word = Console.ReadLine();            
            
            sw.Reset();
            sw.Start();
            myLinkedList.AddLast(word);
            Console.WriteLine($"Word '{word}' added at the end.");
            sw.Stop();
            Console.WriteLine($"Time taken to load: {sw.Elapsed} ms");
        }

        // Insert word before another word in the list
        static void InsertBefore()
        {

            Console.Clear();
            Console.WriteLine("**** Add Before ****");
            Console.Write("Enter the target word: ");
            string targetWord = Console.ReadLine();
            Console.Write("Enter the word to insert before the target word: ");
            string newWord = Console.ReadLine();            
            
            sw.Reset();
            sw.Start();
            myLinkedList.AddBefore(targetWord, newWord);
            sw.Stop();
            Console.WriteLine($"Time taken to load: {sw.Elapsed} ms");
        }

        // Insert word after another word in the list
        static void InsertAfter()
        {

            Console.Clear();
            Console.WriteLine("**** Add After ****");
            Console.Write("Enter the target word: ");
            string targetWord = Console.ReadLine();
            Console.Write("Enter the word to insert after the target word: ");
            string newWord = Console.ReadLine();            
            
            sw.Reset();
            sw.Start();
            myLinkedList.AddAfter(targetWord, newWord);
            sw.Stop();
            Console.WriteLine($"Time taken to load: {sw.Elapsed} ms");
        }
    }
    //Finding a word from the list
    static void FindMenu()
    {
        Console.Clear();
        Console.WriteLine("**** Find Word ****");
        Console.Write("Enter the word to find: ");
        string word = Console.ReadLine();
        sw.Reset();
        sw.Start();
        myLinkedList.Find(word);
        sw.Stop();
        Console.WriteLine($"Time taken to find: {sw.ElapsedMilliseconds} ms");
    }
    //Deleting a word from the list
    static void DeleteMenu()
    {
            bool exit = false;

            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("**** Delete Word Menu ****");
                Console.WriteLine("1. Delete at Front");
                Console.WriteLine("2. Delete at End");
                Console.WriteLine("3. Delete by Word");
                Console.WriteLine("4. Return to Main Menu");
                Console.WriteLine();
                Console.Write("Enter your choice: ");

                int choice;
                if (int.TryParse(Console.ReadLine(), out choice))
                {
                    switch (choice)
                    {
                        case 1:
                            DeleteAtFront();
                            break;

                        case 2:
                            DeleteAtEnd();
                            break;

                        case 3:
                            DeleteByWord();
                            break;

                        case 4:
                            exit = true; // Return to main menu
                            break;

                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                }

                if (!exit)
                {
                    Console.WriteLine("\nPress any key to return to the delete menu...");
                    Console.ReadKey();
                }
            }
        }

        // Delete the first node
        static void DeleteAtFront()
        {
            myLinkedList.DeleteAtFront();
        }

        // Delete the last node
        static void DeleteAtEnd()
        {
            myLinkedList.DeleteAtEnd();
        }

        // Delete a node by word
        static void DeleteByWord()
        {
            Console.Clear();
            Console.WriteLine("**** Delete Word ****");
            Console.Write("Enter the word to delete: ");
            string word = Console.ReadLine();
            myLinkedList.Delete(word);
        }
    static void FunctionalTest()
{
    myLinkedList.Clear();
    Console.WriteLine("**** Functional Test Demonstration ****");

    // Step 1: Insert words
    Console.WriteLine("\nStep 1: Inserting words...");
    myLinkedList.AddFirst("apple"); // Add to front
    myLinkedList.AddLast("banana"); // Add to end
    myLinkedList.AddLast("watermelon"); // Add to end
    myLinkedList.AddFirst("kiwi");//Add to front
    myLinkedList.Print();

    // Step 2: Find words
    Console.WriteLine("\nStep 2: Finding words...");
    myLinkedList.Find("banana"); // Should find
    myLinkedList.Find("orange"); // Should not find

    // Step 3: Delete a word
    Console.WriteLine("\nStep 3: Deleting a word...");
    myLinkedList.Delete("banana"); // Should delete
    myLinkedList.Delete("grape"); // Should not find to delete

    // Step 4: Delete at front and end
    Console.WriteLine("\nStep 4: Deleting at front and end...");
    myLinkedList.DeleteAtFront(); // Delete front
    myLinkedList.DeleteAtEnd();   // Delete end

    // Step 5: Print the LinkedList
    Console.WriteLine("\nStep 5: Printing the LinkedList...");
    myLinkedList.Print();

    Console.WriteLine("\nFunctional test completed.");
    Console.WriteLine("Press any key to return to the main menu...");
    Console.ReadKey();
}
    }





