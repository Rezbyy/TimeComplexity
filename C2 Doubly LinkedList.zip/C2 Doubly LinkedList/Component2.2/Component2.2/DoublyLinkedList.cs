﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Component2;
public class DoublyLinkedList
{
    public Node Head { get; set; }
    private Node Tail { get; set; }

    public DoublyLinkedList()
    {
        Head = null;
        Tail = null;
    }

    // Add a new word to the start of the doubly linked list
    public void AddFirst(string word)
    {
        Node node = new Node(word);
        if (Head == null) // List is empty
        {
            Head = node;
            Tail = node;
        }
        else
        {
            node.Next = Head;
            Head.Previous = node;
            Head = node;
        }
    }

    // Add a new word to the end of the doubly linked list
    public void AddLast(string word)
    {
        Node node = new Node(word);
        if (Head == null) // List is empty
        {
            Head = node;
            Tail = node;
        }
        else
        {
            Tail.Next = node;
            node.Previous = Tail;
            Tail = node;
        }
    }

    // Add a new word before an existing word in the doubly linked list
    public void AddBefore(string targetWord, string newWord)
    {
        Node targetNode = Find(targetWord);
        if (targetNode == null)
        {
            Console.WriteLine($"Word '{targetWord}' not found. Cannot add before.");
            return;
        }

        Node node = new Node(newWord);

        if (targetNode == Head) // If the target is the head, use AddFirst
        {
            AddFirst(newWord);
        }
        else
        {
            node.Next = targetNode;
            node.Previous = targetNode.Previous;
            targetNode.Previous.Next = node;
            targetNode.Previous = node;
        }
    }

    // Add a new word after an existing word in the doubly linked list
    public void AddAfter(string targetWord, string newWord)
    {
        Node targetNode = Find(targetWord);
        if (targetNode == null)
        {
            Console.WriteLine($"Word '{targetWord}' not found. Cannot add after.");
            return;
        }

        Node node = new Node(newWord);

        if (targetNode == Tail) // If the target is the tail, use AddLast
        {
            AddLast(newWord);
        }
        else
        {
            node.Next = targetNode.Next;
            node.Previous = targetNode;
            targetNode.Next.Previous = node;
            targetNode.Next = node;
        }
    }

    // Clear the list
    public void Clear()
    {
        Head = null;
        Tail = null;
    }

    // Find a word in the list
    public Node Find(string word)
    {
        Node currentNode = Head;
        while (currentNode != null)
        {
            if (currentNode.Word == word)
            {
                Console.WriteLine($"Found: {currentNode}");
                return currentNode;
            }
            currentNode = currentNode.Next;
        }
        Console.WriteLine($"The word '{word}' was not found in the Doubly Linked List.");
        return null;
    }

    // Delete a word from the list
    public void Delete(string word)
    {
        Node currentNode = Head;
        while (currentNode != null)
        {
            if (currentNode.Word == word)
            {
                // If it's the head node
                if (currentNode == Head)
                {
                    Head = currentNode.Next;
                    if (Head != null) // Update the head's previous to null
                        Head.Previous = null;
                }
                // If it's the tail node
                else if (currentNode == Tail)
                {
                    Tail = currentNode.Previous;
                    if (Tail != null) // Update the tail's next to null
                        Tail.Next = null;
                }
                // If it's in the middle
                else
                {
                    currentNode.Previous.Next = currentNode.Next;
                    currentNode.Next.Previous = currentNode.Previous;
                }

                Console.WriteLine($"Deleted: {word}");
                return;
            }
            currentNode = currentNode.Next;
        }
        Console.WriteLine($"The word '{word}' was not found in the Doubly Linked List.");
    }


    // Delete the first node
    public void DeleteAtFront()
    {
        if (Head == null)
        {
            Console.WriteLine("The list is empty. No word to delete.");
            return;
        }

        string word = Head.Word;
        if (Head == Tail) // Only one element in the list
        {
            Head = null;
            Tail = null;
        }
        else
        {
            Head =  Head.Next;
            Head.Previous = null;
        }

        Console.WriteLine($"Deleted: {word} from the front.");
    }

    // Delete the last node
    public void DeleteAtEnd()
    {
        if (Tail == null)
        {
            Console.WriteLine("The list is empty. No word to delete.");
            return;
        }

        string word = Tail.Word;
        if (Head == Tail) // Only one element in the list
        {
            Head = null;
            Tail = null;
        }
        else
        {
            Tail = Tail.Previous;
            Tail.Next = null;
        }

        Console.WriteLine($"Deleted: {word} from the end.");
    }
    public void Print()
    {
        if (Head == null)
        {
            Console.WriteLine("The Doubly Linked List is empty.");
            return;
        }

        Node currentNode = Head;
        while (currentNode != null)
        {
            Console.WriteLine(currentNode);
            currentNode = currentNode.Next;
        }
    }
}
    // Additional methods (Clear, Find, Delete, Print, etc.) remain the same...
// Print the list from start to end
