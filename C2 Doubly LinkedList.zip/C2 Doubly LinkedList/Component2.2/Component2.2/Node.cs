﻿namespace Component2;
public class Node
{
    public string Word { get; set; }
    public int Length { get; set; }
    public Node Previous { get; set; }  // Reference to the previous node
    public Node Next { get; set; }      // Reference to the next node

    public Node()
    {
        Word = null;
        Length = 0;
        Previous = null;
        Next = null;
    }

    public Node(string word)
    {
        Word = word;
        Length = word.Length;
        Previous = null;
        Next = null;
    }

    public override string ToString()
    {
        return $"Word: {Word}, Length: {Length}";
    }
}
