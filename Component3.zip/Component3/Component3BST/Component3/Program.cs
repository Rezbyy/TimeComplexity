﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Diagnostics;

namespace Component3
{
    internal class Program
    {
        private static BSTree bst = new BSTree();
        private static Stopwatch sw = new Stopwatch(); // Initialize Stopwatch

        static void Main(string[] args)
        {
            MainMenu();
            Console.WriteLine("");
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        static void MainMenu() // Main menu for loading, inserting, finding, and deleting operations
        {
            int choice;
            bool exit = false;

            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("**** Binary Search Tree Menu ****");
                Console.WriteLine("1. Load File");
                Console.WriteLine("2. Insert Word");
                Console.WriteLine("3. Find Word");
                Console.WriteLine("4. Delete Word");
                Console.WriteLine("5. Print BST");
                Console.WriteLine("6. Functional Test Demonstration");
                Console.WriteLine("7. Display Node Height and Depth");
                Console.WriteLine("8. Exit");
                Console.WriteLine();
                Console.Write("Enter your choice: ");

                if (int.TryParse(Console.ReadLine(), out choice))
                {
                    switch (choice)
                    {
                        case 1:
                            LoadMenu();
                            break;
                        case 2:
                            InsertMenu();
                            break;
                        case 3:
                            FindMenu();
                            break;
                        case 4:
                            DeleteMenu();
                            break;
                        case 5:
                            PrintMenu();
                            break;
                        case 6:
                            FunctionalTest();
                            break;
                        case 7:
                            DisplayHeightAndDepth();
                            break;
                        case 8:
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Invalid choice. Please select a valid option.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                }

                if (!exit)
                {
                    Console.WriteLine("\nPress any key to return to the main menu...");
                    Console.ReadKey();
                }
            }
        }

        // Menu for loading files
        static void LoadMenu()
        {
            Console.Clear();
            Console.WriteLine("**** Choose a Folder *****");
            Console.WriteLine("1. Random");
            Console.WriteLine("2. Ordered");
            Console.Write("Enter your option: ");

            if (int.TryParse(Console.ReadLine(), out int folderOpt) && (folderOpt == 1 || folderOpt == 2))
            {
                string folderPath = folderOpt == 1 ? "random" : "ordered";
                LoadFile(folderPath);
            }
            else
            {
                Console.WriteLine("Invalid option. Please try again.");
            }
        }

        // Loading file
        static void LoadFile(string folderPath)
        {
            Console.Clear();
            Console.WriteLine($"**** Choose a File to Load from {folderPath} Folder *****");
            Console.WriteLine("1. 1000-words.txt");
            Console.WriteLine("2. 5000-words.txt");
            Console.WriteLine("3. 10000-words.txt");
            Console.WriteLine("4. 15000-words.txt");
            Console.WriteLine("5. 20000-words.txt");
            Console.WriteLine("6. 25000-words.txt");
            Console.WriteLine("7. 30000-words.txt");
            Console.WriteLine("8. 35000-words.txt");
            Console.WriteLine("9. 40000-words.txt");
            Console.WriteLine("10. 45000-words.txt");
            Console.WriteLine("11. 50000-words.txt");
            Console.Write("Enter your option: ");

            if (int.TryParse(Console.ReadLine(), out int fileOpt) && fileOpt >= 1 && fileOpt <= 11)
            {
                string[] fileNames = new string[]
                {
                "1000-words.txt",
                "5000-words.txt",
                "10000-words.txt",
                "15000-words.txt",
                "20000-words.txt",
                "25000-words.txt",
                "30000-words.txt",
                "35000-words.txt",
                "40000-words.txt",
                "45000-words.txt",
                "50000-words.txt"
                };

                string fileName = fileNames[fileOpt - 1];
                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, folderPath, fileName);

                bst = new BSTree();
                sw.Reset();
                sw.Start();

                if (File.Exists(filePath))
                {
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            if (!line.StartsWith("#"))
                            {
                                bst.Add(line);
                            }
                        }
                    }
                    Console.WriteLine($"File loaded successfully from {filePath}");
                }
                else
                {
                    Console.WriteLine($"File not found: {filePath}");
                }
                sw.Stop();
                Console.WriteLine($"Time taken to load: {sw.ElapsedMilliseconds} ms");
            }
            else
            {
                Console.WriteLine("Invalid option. Please try again.");
            }
        }

        // Menu for inserting word
        static void InsertMenu()
        {
       
            Console.Clear();
            Console.Write("Enter a word to insert: ");
            string word = Console.ReadLine();
            bst.Add(word);
            Console.WriteLine($"Word '{word}' inserted.");
        }

        // Menu for finding word
        static void FindMenu()
        {

            Console.Clear();
            Console.Write("Enter a word to find: ");            
            string word = Console.ReadLine();          
            sw.Reset ();
            sw.Start();
            Node node = bst.Find(word);
            Console.WriteLine(node != null ? $"Found: {node}" : $"Word '{word}' not found.");
            sw.Stop();
            Console.WriteLine($"Time taken to find: {sw.ElapsedMilliseconds} ms");
        }

        // Menu for deleting word
        static void DeleteMenu()
        {
            Console.Clear();
            Console.Write("Enter a word to delete: ");
            string word = Console.ReadLine();            
            sw.Reset();
            sw.Start();
            string result = bst.Remove(word);
            Console.WriteLine(result);
            sw.Stop();
            Console.WriteLine($"Time taken to delete: {sw.ElapsedMilliseconds} ms");
        }

        // Menu for printing tree traversals
        static void PrintMenu()
        {
            Console.Clear();
            Console.WriteLine("1. Pre-Order Traversal");
            Console.WriteLine("2. In-Order Traversal");
            Console.WriteLine("3. Post-Order Traversal");
            Console.Write("Enter your choice: ");
            if (int.TryParse(Console.ReadLine(), out int option))
            {
                switch (option)
                {
                    case 1:
                        sw.Reset();
                        sw.Start();
                        Console.WriteLine("Pre-Order Traversal:");
                        Console.WriteLine(bst.PreOrder());
                        sw.Stop();
                        Console.WriteLine($"Time taken to order: {sw.ElapsedMilliseconds} ms");
                        break;
                    case 2:
                        sw.Reset();
                        sw.Start();
                        Console.WriteLine("In-Order Traversal:");
                        Console.WriteLine(bst.InOrder());
                        sw.Stop();
                        Console.WriteLine($"Time taken to order: {sw.ElapsedMilliseconds} ms");
                        break;
                    case 3:
                        sw.Reset();
                        sw.Start();
                        Console.WriteLine("Post-Order Traversal:");
                        Console.WriteLine(bst.PostOrder());
                        sw.Stop();
                        Console.WriteLine($"Time taken to order: {sw.ElapsedMilliseconds} ms");
                        break;
                    default:
                        Console.WriteLine("Invalid choice.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Invalid input.");
            }
        }

        // Functional Test to demonstrate operations
        static void FunctionalTest()
        {
            Console.Clear();
            Console.WriteLine("**** Functional Test ****");
            bst.Add("apple");
            bst.Add("banana");
            bst.Add("orange");
            Console.WriteLine("Inserted 'apple', 'banana', and 'orange'.");

            Console.WriteLine("In-Order Traversal:");
            Console.WriteLine(bst.InOrder());

            Console.WriteLine("\nFinding 'banana':");
            Console.WriteLine(bst.Find("banana") != null ? "'banana' found." : "'banana' not found.");

            Console.WriteLine("\nDeleting 'banana':");
            Console.WriteLine(bst.Remove("banana"));

            Console.WriteLine("In-Order Traversal After Deletion:");
            Console.WriteLine(bst.InOrder());
        }

        // Display height and depth of a node
        static void DisplayHeightAndDepth()
        {
            Console.Clear();
            Console.Write("Enter a word to find height and depth: ");
            string word = Console.ReadLine();
            Console.WriteLine(bst.DisplayHeightAndDepth(word));
        }
    }
}