﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

namespace Component3
{
    internal class BSTree
    {
        public Node Root { get; set; }

        public BSTree()
        {
            Root = null;
        }

        #region Insert
        private void InsertNode(Node tree, Node node)
        {
            if (string.Compare(node.Word, tree.Word) < 0)
            {
                if (tree.Left == null)
                {
                    tree.Left = node;
                }
                else
                {
                    InsertNode(tree.Left, node);
                }
            }
            else if (string.Compare(node.Word, tree.Word) > 0)
            {
                if (tree.Right == null)
                {
                    tree.Right = node;
                }
                else
                {
                    InsertNode(tree.Right, node);
                }
            }
        }

        public void Add(string word)
        {
            Node node = new Node(word);
            if (Root == null)
            {
                Root = node;
            }
            else
            {
                InsertNode(Root, node);
            }
        }
        #endregion

        #region Find
        public Node Find(string word)
        {
            return FindNode(Root, word);
        }

        private Node FindNode(Node node, string word)
        {
            if (node == null || node.Word == word) return node;
            if (string.Compare(word, node.Word) < 0)
                return FindNode(node.Left, word);
            else
                return FindNode(node.Right, word);
        }
        #endregion

        #region Delete
        private Node Delete(Node tree, string word)
        {
            if (tree == null)
            {
                return tree;
            }

            if (string.Compare(word, tree.Word) < 0)
            {
                tree.Left = Delete(tree.Left, word);
            }
            else if (string.Compare(word, tree.Word) > 0)
            {
                tree.Right = Delete(tree.Right, word);
            }
            else
            {
                if (tree.Left == null)
                {
                    return tree.Right;
                }
                else if (tree.Right == null)
                {
                    return tree.Left;
                }
                else
                {
                    tree.Word = MinValue(tree.Right);
                    tree.Right = Delete(tree.Right, tree.Word);
                }
            }
            return tree;
        }

        private string MinValue(Node node)
        {
            string minValue = node.Word;
            while (node.Left != null)
            {
                minValue = node.Left.Word;
                node = node.Left;
            }
            return minValue;
        }

        public string Remove(string word)
        {
            Root = Delete(Root, word);
            return $"Target: {word}, Node Removed";
        }
        #endregion

        #region ToPrint (Traversal Methods)

        #region Pre-Order
        private string PreOrder(Node node)
        {
            StringBuilder sb = new StringBuilder();
            if (node != null)
            {
                sb.AppendLine(node.ToString()); // Print current node
                sb.Append(PreOrder(node.Left)); // Traverse left subtree
                sb.Append(PreOrder(node.Right)); // Traverse right subtree
            }
            return sb.ToString();
        }

        public string PreOrder()
        {
            return Root == null ? "TREE is EMPTY" : PreOrder(Root);
        }
        #endregion

        #region In-Order
        private string InOrder(Node node)
        {
            StringBuilder sb = new StringBuilder();
            if (node != null)
            {
                sb.Append(InOrder(node.Left)); // Traverse left subtree
                sb.AppendLine(node.ToString()); // Print current node
                sb.Append(InOrder(node.Right)); // Traverse right subtree
            }
            return sb.ToString();
        }

        public string InOrder()
        {
            return Root == null ? "TREE is EMPTY" : InOrder(Root);
        }
        #endregion

        #region Post-Order
        private string PostOrder(Node node)
        {
            StringBuilder sb = new StringBuilder();
            if (node != null)
            {
                sb.Append(PostOrder(node.Left)); // Traverse left subtree
                sb.Append(PostOrder(node.Right)); // Traverse right subtree
                sb.AppendLine(node.ToString()); // Print current node

            }
            return sb.ToString();
        }

        public string PostOrder()
        {
            return Root == null ? "TREE is EMPTY" : PostOrder(Root);
        }
        #endregion

        #endregion

        #region Extra Credit: Height and Depth

        public int GetHeight(Node node)
        {
            if (node == null) return -1;  // Height of an empty node is -1
            int leftHeight = GetHeight(node.Left);
            int rightHeight = GetHeight(node.Right);
            return Math.Max(leftHeight, rightHeight) + 1;
        }

        public int GetDepth(string word)
        {
            return GetDepthHelper(Root, word, 0);
        }

        private int GetDepthHelper(Node node, string word, int depth)
        {
            if (node == null) return -1; // Word not found
            if (node.Word == word) return depth;
            if (string.Compare(word, node.Word) < 0)
                return GetDepthHelper(node.Left, word, depth + 1);
            else
                return GetDepthHelper(node.Right, word, depth + 1);
        }

        public string DisplayHeightAndDepth(string word)
        {
            Node node = Find(word);
            if (node != null)
            {
                int height = GetHeight(node);
                int depth = GetDepth(word);
                return $"Node '{word}' has Height: {height} and Depth: {depth}.";
            }
            return $"Node '{word}' not found.";
        }
        #endregion
    }
}