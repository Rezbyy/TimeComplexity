﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Comp3AVL
{
    internal class AVLTree
    {
        public Node Root { get; set; }

        public AVLTree()
        {
            Root = null;
        }

        #region Read and Add Operations
        public List<string> ReadFile(string filePath)
        {
            List<string> words = new List<string>();
            try
            {
                using (var reader = new System.IO.StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (!line.StartsWith("#"))
                        {
                            words.Add(line);
                        }
                    }
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Error: Unable to load/read file");
            }
            return words;
        }

        public void AddOp(List<string> words)
        {
            foreach (var word in words)
            {
                Add(word);
            }
        }
        #endregion

        #region Add and Insert with Balancing
        public void Add(string word)
        {
            int wordLength = word.Length;
            Node node = new Node(word);
            Root = Root == null ? node : InsertNode(Root, node);
        }

        private Node InsertNode(Node tree, Node node)
        {
            if (tree == null) return node;

            if (node.Word.CompareTo(tree.Word) < 0)
            {
                tree.Left = InsertNode(tree.Left, node);
            }
            else if (node.Word.CompareTo(tree.Word) > 0)
            {
                tree.Right = InsertNode(tree.Right, node);
            }

            return BalanceTree(tree);
        }
        #endregion

        #region Balance and Rotation Methods
        private Node BalanceTree(Node current)
        {
            int balanceFactor = BalanceFactor(current);

            if (balanceFactor > 1)
            {
                if (BalanceFactor(current.Left) > 0)
                    current = RotateLL(current);
                else
                    current = RotateLR(current);
            }
            else if (balanceFactor < -1)
            {
                if (BalanceFactor(current.Right) > 0)
                    current = RotateRL(current);
                else
                    current = RotateRR(current);
            }
            return current;
        }

        private Node RotateRR(Node parent)
        {
            Node pivot = parent.Right;
            parent.Right = pivot.Left;
            pivot.Left = parent;
            return pivot;
        }

        private Node RotateRL(Node parent)
        {
            parent.Right = RotateLL(parent.Right);
            return RotateRR(parent);
        }

        private Node RotateLL(Node parent)
        {
            Node pivot = parent.Left;
            parent.Left = pivot.Right;
            pivot.Right = parent;
            return pivot;
        }

        private Node RotateLR(Node parent)
        {
            parent.Left = RotateRR(parent.Left);
            return RotateLL(parent);
        }

        private int GetHeight(Node node)
        {
            return node == null ? -1 : Math.Max(GetHeight(node.Left), GetHeight(node.Right)) + 1;
        }

        private int BalanceFactor(Node node)
        {
            return GetHeight(node.Left) - GetHeight(node.Right);
        }
        #endregion

        #region Traversal Methods
        private string TraversePreOrder(Node node)
        {
            StringBuilder sb = new StringBuilder();
            if (node != null)
            {
                sb.AppendLine(node.ToString());
                sb.Append(TraversePreOrder(node.Left));
                sb.Append(TraversePreOrder(node.Right));
            }
            return sb.ToString();
        }

        public string PreOrder()
        {
            return Root == null ? "Tree is EMPTY" : TraversePreOrder(Root);
        }

        private string TraverseInOrder(Node node)
        {
            StringBuilder sb = new StringBuilder();
            if (node != null)
            {
                sb.Append(TraverseInOrder(node.Left));
                sb.AppendLine(node.ToString());
                sb.Append(TraverseInOrder(node.Right));
            }
            return sb.ToString();
        }

        public string InOrder()
        {
            return Root == null ? "Tree is EMPTY" : TraverseInOrder(Root);
        }

        private string TraversePostOrder(Node node)
        {
            StringBuilder sb = new StringBuilder();
            if (node != null)
            {
                sb.Append(TraversePostOrder(node.Left));
                sb.Append(TraversePostOrder(node.Right));
                sb.AppendLine(node.ToString());
            }
            return sb.ToString();
        }

        public string PostOrder()
        {
            return Root == null ? "Tree is EMPTY" : TraversePostOrder(Root);
        }
        #endregion

        #region Deletion
        private Node Delete(Node current, Node target)
        {
            if (current == null) return null;

            if (target.Word.CompareTo(current.Word) < 0)
            {
                current.Left = Delete(current.Left, target);
            }
            else if (target.Word.CompareTo(current.Word) > 0)
            {
                current.Right = Delete(current.Right, target);
            }
            else
            {
                if (current.Right != null)
                {
                    Node minLargerNode = GetMin(current.Right);
                    current.Word = minLargerNode.Word;
                    current.Right = Delete(current.Right, minLargerNode);
                }
                else
                {
                    return current.Left;
                }
            }

            return BalanceTree(current);
        }

        private Node GetMin(Node node)
        {
            while (node.Left != null)
                node = node.Left;
            return node;
        }

        public string Remove(string word)
        {
            Node target = new Node(word);
            Node foundNode = Search(Root, target);
            if (foundNode != null)
            {
                Root = Delete(Root, target);
                return $"Target: {foundNode} removed.";
            }
            return $"Target: {word} not found or tree empty.";
        }
        #endregion

        #region Search, Depth, and Height
        private Node Search(Node node, Node target)
        {
            if (node == null) return null;
            if (target.Word == node.Word) return node;

            return target.Word.CompareTo(node.Word) < 0 ? Search(node.Left, target) : Search(node.Right, target);
        }

        public Node Find(string word)
        {
            return Search(Root, new Node(word));
        }

        public string GetDepth(string word)
        {
            Node foundNode = Search(Root, new Node(word));
            if (foundNode == null) return "Node not found";

            int depth = NodeDepth(Root, foundNode, 0);
            return $"Node Depth: {depth}";
        }

        private int NodeDepth(Node node, Node target, int depth)
        {
            if (node == null) return -1;
            if (node.Word == target.Word) return depth;

            return target.Word.CompareTo(node.Word) < 0
                ? NodeDepth(node.Left, target, depth + 1)
                : NodeDepth(node.Right, target, depth + 1);
        }

        public string GetHeight(string word)
        {
            Node foundNode = Search(Root, new Node(word));
            return foundNode == null ? "Node not found" : $"Node Height: {HeightMe(foundNode)}";
        }

        private int HeightMe(Node node)
        {
            if (node == null) return -1;

            int leftHeight = HeightMe(node.Left);
            int rightHeight = HeightMe(node.Right);
            return Math.Max(leftHeight, rightHeight) + 1;
        }
        #endregion

        #region Clear
        public void ClearMe()
        {
            Root = null;
        }
        #endregion

        public string DisplayHeightAndDepth(string word)
        {
            string depth = GetDepth(word);
            string height = GetHeight(word);
            return $"{depth}\n{height}";
        }
    }
}
